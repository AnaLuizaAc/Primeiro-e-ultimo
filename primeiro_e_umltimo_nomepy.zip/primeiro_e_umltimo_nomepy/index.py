nome = input("Digite seu nome inteiro: ")

nomeD = nome.split(" ")
print("Primeiro nome: ", nomeD[0])
print("seu ultimo nome: ", nomeD[-1])

